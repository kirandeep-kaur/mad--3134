<?php
$host="localhost";
$user="root";
$pass="";
$conn=mysql_connect("$host","$user","$pass");
if(!$conn)
{
echo "Not connnected";
}
else
{
echo "";
}
?>