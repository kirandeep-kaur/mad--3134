<html>
<head>
<style>
a
{
	decoration:none;
	color: white;
}
</style>
</head>
<body>
<div style="width:100%;height:10%;background-color:#3d3d29">
<h1 style="font-size:200%;color:white" align="center">Payroll Management System</h1>

</div>
</body>
</html>