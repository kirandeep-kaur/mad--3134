<div style="background-color:#3d3d29;width:100%;height:10%;clear:both">
<h3 align="right" style="font-size:150%;color:white">Made By: Name 1  Name2</h4>
</div>